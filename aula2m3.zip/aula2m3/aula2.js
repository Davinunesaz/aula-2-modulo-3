var msg = 'Hello World modulo 3';
console.log(msg);